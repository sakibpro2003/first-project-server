# Requirement Analysis and Entity-Relationship (ER) Diagram

## Requirement Analysis

([Requirement Analysis - 👈 Click Here](https://docs.google.com/document/d/10mkjS8boCQzW4xpsESyzwCCLJcM3hvLghyD_TeXPBx0/edit?usp=sharing))

*Description*: This document represents the requirement analysis of part-1.

## Entity-Relationship (ER) Diagram

![ER Diagram](./ER_Diagram2.png)

*Description*: This diagram represents the entities and their relationships in the system.