export const CourseSearchableFields = ['title', 'prefix', 'code'];
